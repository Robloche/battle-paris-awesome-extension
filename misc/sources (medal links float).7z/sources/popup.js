var battleParisEnhancer = {

	zoom: 2,

	checkPage: function() {
		var obj = this;
		chrome.tabs.query({
			active: true,
			lastFocusedWindow: true
		}, function(tabs) {
			var url = tabs[0].url;
			if (url.indexOf('battle.paris/medals/') > -1 || url.indexOf('battleparis.com/medals/') > -1) {
				// Medal page
				obj.checkLoggedUser();
			}
			else {
				// Not a medal page: display links to all medals
				$('body').width(700);
				
				var medalsDiv = $('#medal-list');
				$(rewards).each(function() {
					$('<img />').attr({
						src: 'http://battle.paris/static/Rewards/' + this.image + '.png',
						title: this.name
					}).addClass('medal-link').appendTo($('<a />').attr({
						href: 'http://battle.paris/medals/' + this.name + '/'
					}).appendTo(medalsDiv));
				});
				medalsDiv.show();
				
				$('.medal-link').hover(
					function() {
						var width = $('.medal-link').width() + obj.zoom;
						var height = $('.medal-link').height() + obj.zoom;

						$(this).stop(false,true).animate({ 'width': width, 'height': height, 'margin': -obj.zoom }, { duration: 200 });
					},
					function() {
						$(this).stop(false,true).animate({ 'width': 62, 'height': 62, 'margin': 0 }, { duration: 100 });    
					}
				);
				
				$('body').on('click', 'a', function(){
					chrome.tabs.create({ url: $(this).attr('href') });
					return false;
				});
			}
		});
	},

	checkLoggedUser: function() {
		chrome.tabs.executeScript(null, { file: 'jquery-2.1.3.min.js' }, function() {
			chrome.tabs.executeScript(null, { file: 'poi-count.js' });
		});
	},
	
	updatePopup: function(e) {	
		if (e.logged) {	
			$('#logged').show();
			$('#checked-poi-label').text(chrome.i18n.getMessage('checkedPoi'));
			$('#left-poi-label').text(chrome.i18n.getMessage('leftPoi'));
			$('#total-checked-label').text(chrome.i18n.getMessage('totalChecked'));
			$('#checked-poi').text(e.checked);
			$('#total-poi').text(e.checked + e.left);
			$('#left-poi').text(e.left);
			$('#total-checked').text(e.total);
			$('#picto').attr('src', e.picto);
			$('#medal-name').text(e.name);
		}
		else {
			$('#not-logged').text(chrome.i18n.getMessage('notLogged')).show();
		}
	}
};

$(function() {
	chrome.runtime.onMessage.addListener(function(e, sender) {
		battleParisEnhancer.updatePopup(e);
	});

	battleParisEnhancer.checkPage();
});

// <div class="reward" title="Tu étais à l&#39;apéro mensuel de BattleParis. Et à la santé du Colonel, tout particulièrement !"><a href="/medals/Apéro ! (événement)/">
					// <div class="reward_picture"><img src="/static/Rewards/apero.png" alt="Apéro ! (événement)" /></div>
					// <div class="reward_name t5">Apéro ! (événement)</div>
				// </a></div>
			
				// <div class="reward" title="Tes adversaires ont apprécié tes petits cadeaux, le plus grand artificier de la Saison 1, c&#39;est toi. Chapeau « l&#39;artiste » !"><a href="/medals/Artificier en Chef/">
					// <div class="reward_picture"><img src="/static/Rewards/first_mine.png" alt="Artificier en Chef" /></div>
					// <div class="reward_name t5">Artificier en Chef</div>
				// </a></div>
			
				// <div class="reward" title="Obtenue en checkant 10 fois au moins 4 salles de concert différentes. Comme ça on aime la bonne musique ?"><a href="/medals/Band on the Run/">
					// <div class="reward_picture"><img src="/static/Rewards/mission_bandontherun02.png" alt="Band on the Run" /></div>
					// <div class="reward_name t5">Band on the Run</div>
				// </a></div>
			
				// <div class="reward" title="Visitez les principales caisses de communauté parisiennes : celle d&#39;Allocation Familiale à Grenelle, et celle d&#39;Assurance Maladie à Flandre."><a href="/medals/Battlepoly - Caisse de Communauté/">
					// <div class="reward_picture"><img src="/static/Rewards/battlepoly_community.png" alt="Battlepoly - Caisse de Communauté" /></div>
					// <div class="reward_name t5">Battlepoly - Caisse de Communauté</div>
				// </a></div>
			
				// <div class="reward" title="Bravo, vous avez trouvé la case départ de Battlepoly ! Recevez 20&#39;000 F chaque fois que vous pass... nan on déconne."><a href="/medals/Battlepoly - Case Départ/">
					// <div class="reward_picture"><img src="/static/Rewards/battlepoly_start.png" alt="Battlepoly - Case Départ" /></div>
					// <div class="reward_name t5">Battlepoly - Case Départ</div>
				// </a></div>
			
				// <div class="reward" title="Allez en prison. Rendez-vous directement à la case Prison de la Santé, ne franchissez pas la case &quot;Départ&quot;. Ne touchez pas 20.000 F."><a href="/medals/Battlepoly - Case Prison/">
					// <div class="reward_picture"><img src="/static/Rewards/battlepoly_prison.png" alt="Battlepoly - Case Prison" /></div>
					// <div class="reward_name t5">Battlepoly - Case Prison</div>
				// </a></div>
			
				// <div class="reward" title="Visitez les 5 grands réservoirs fournissant Paris en eau potable. Cherchez les pelouses !"><a href="/medals/Battlepoly - Les Eaux/">
					// <div class="reward_picture"><img src="/static/img/ordre.png" alt="Battlepoly - Les Eaux" /></div>
					// <div class="reward_name t5">Battlepoly - Les Eaux</div>
				// </a></div>
			
				// <div class="reward" title="Devient le roi du rail en checkant les 4 grandes gares de Paris ! Soit les gares SNCF du Nord, de Saint-Lazare, de Lyon et Montparnasse."><a href="/medals/Battlepoly - Les Gares/">
					// <div class="reward_picture"><img src="/static/Rewards/battlepoly_gares.png" alt="Battlepoly - Les Gares" /></div>
					// <div class="reward_name t5">Battlepoly - Les Gares</div>
				// </a></div>
			
				// <div class="reward" title="Visitez les premiers numéros des rues de Vaugirard, de Courcelles et de l&#39;Avenue de la République."><a href="/medals/Battlepoly - Rues Ciel/">
					// <div class="reward_picture"><img src="/static/Rewards/battlepoly_ciel.png" alt="Battlepoly - Rues Ciel" /></div>
					// <div class="reward_name t5">Battlepoly - Rues Ciel</div>
				// </a></div>
			
				// <div class="reward" title="Visitez les premiers numéros du Faubourg Saint-Honoré, de la Place de la Bourse et de la rue Lafayette."><a href="/medals/Battlepoly - Rues Jaunes/">
					// <div class="reward_picture"><img src="/static/Rewards/battlepoly_jaune.png" alt="Battlepoly - Rues Jaunes" /></div>
					// <div class="reward_name t5">Battlepoly - Rues Jaunes</div>
				// </a></div>
			
				// <div class="reward" title="Visitez les premiers numéros de l&#39;Avenue des Champs-Élysées et de la rue de la Paix."><a href="/medals/Battlepoly - Rues Marines/">
					// <div class="reward_picture"><img src="/static/Rewards/battlepoly_marine.png" alt="Battlepoly - Rues Marines" /></div>
					// <div class="reward_name t5">Battlepoly - Rues Marines</div>
				// </a></div>
			
				// <div class="reward" title="Visitez les premiers numéros de l&#39;Avenue Mozart, du Boulevard Saint-Michel et de la Place Pigalle."><a href="/medals/Battlepoly - Rues Oranges/">
					// <div class="reward_picture"><img src="/static/img/ordre.png" alt="Battlepoly - Rues Oranges" /></div>
					// <div class="reward_name t5">Battlepoly - Rues Oranges</div>
				// </a></div>
			
				// <div class="reward" title="Visitez les premiers numéros du Boulevard de Belleville et de la rue Lecourbe."><a href="/medals/Battlepoly - Rues Roses/">
					// <div class="reward_picture"><img src="/static/Rewards/battlepoly_rose.png" alt="Battlepoly - Rues Roses" /></div>
					// <div class="reward_name t5">Battlepoly - Rues Roses</div>
				// </a></div>
			
				// <div class="reward" title="Visitez les premiers numéros de l&#39;Avenue Matignon, du Boulevard Malesherbes et de l&#39;Avenue Henri-Martin."><a href="/medals/Battlepoly - Rues Rouges/">
					// <div class="reward_picture"><img src="/static/Rewards/battlepoly_rouge.png" alt="Battlepoly - Rues Rouges" /></div>
					// <div class="reward_name t5">Battlepoly - Rues Rouges</div>
				// </a></div>
			
				// <div class="reward" title="Visitez les premiers numéros des Avenues de Breteuil, Foch et du Boulevard des Capucines."><a href="/medals/Battlepoly - Rues Vertes/">
					// <div class="reward_picture"><img src="/static/Rewards/battlepoly_vert.png" alt="Battlepoly - Rues Vertes" /></div>
					// <div class="reward_name t5">Battlepoly - Rues Vertes</div>
				// </a></div>
			
				// <div class="reward" title="Visitez les premiers numéros du Boulevard de la Villette, de l&#39;Avenue de Neuilly et de la rue de Paradis."><a href="/medals/Battlepoly - Rues Violettes/">
					// <div class="reward_picture"><img src="/static/Rewards/battlepoly_violet.png" alt="Battlepoly - Rues Violettes" /></div>
					// <div class="reward_name t5">Battlepoly - Rues Violettes</div>
				// </a></div>
			
				// <div class="reward" title="Visitez le cœur vibrant du luxe parisien, la place Vendôme et ses bijoutiers."><a href="/medals/Battlepoly - Taxe de Luxe/">
					// <div class="reward_picture"><img src="/static/Rewards/battlepoly_luxe.png" alt="Battlepoly - Taxe de Luxe" /></div>
					// <div class="reward_name t5">Battlepoly - Taxe de Luxe</div>
				// </a></div>
			
				// <div class="reward" title="Alors comme ça tu as récupéré toutes les cartes du Battlepoly ? Tu as bien le droit à la carte ultime pour ta peine !"><a href="/medals/Battlepoly - Ticket d&#39;Or/">
					// <div class="reward_picture"><img src="/static/img/ordre.png" alt="Battlepoly - Ticket d&#39;Or" /></div>
					// <div class="reward_name t5">Battlepoly - Ticket d&#39;Or</div>
				// </a></div>
			
				// <div class="reward" title="Visitez le siège de la Compagnie de distribution d&#39;Électicité de France au Roule, et sa tour à la Défense."><a href="/medals/Battlepoly - Électricité/">
					// <div class="reward_picture"><img src="/static/Rewards/battlepoly_electric.png" alt="Battlepoly - Électricité" /></div>
					// <div class="reward_name t5">Battlepoly - Électricité</div>
				// </a></div>
			
				// <div class="reward" title="Ton premier checkin, comme c&#39;est mignon !"><a href="/medals/Bleu-bite/">
					// <div class="reward_picture"><img src="/static/Rewards/generic_bleubite.png" alt="Bleu-bite" /></div>
					// <div class="reward_name t5">Bleu-bite</div>
				// </a></div>
			
				// <div class="reward" title="Tu as compris le truc, 50 victimes sont tombées dans tes pièges. Redoutable."><a href="/medals/Bomberman/">
					// <div class="reward_picture"><img src="/static/Rewards/generic_mine03.png" alt="Bomberman" /></div>
					// <div class="reward_name t5">Bomberman</div>
				// </a></div>
			
				// <div class="reward" title="On prend l’avion pour la première fois ? J’espère que tu n’as pas le mal de l’air !"><a href="/medals/Bon Voyage !/">
					// <div class="reward_picture"><img src="/static/Rewards/plane01_big.png" alt="Bon Voyage !" /></div>
					// <div class="reward_name t5">Bon Voyage !</div>
				// </a></div>
			
				// <div class="reward" title="Pour mériter sa Carte de Presse, il faut passer dans au moins 4 rédactions différentes. Au boulot !"><a href="/medals/Carte de Presse/">
					// <div class="reward_picture"><img src="/static/Rewards/news_presse.png" alt="Carte de Presse" /></div>
					// <div class="reward_name t5">Carte de Presse</div>
				// </a></div>
			
				// <div class="reward" title="Pour mériter sa Carte de Radiotélé, il faut passer dans au moins 4 studios différents. Au boulot !"><a href="/medals/Carte de Radiotélé/">
					// <div class="reward_picture"><img src="/static/Rewards/news_radiotv.png" alt="Carte de Radiotélé" /></div>
					// <div class="reward_name t5">Carte de Radiotélé</div>
				// </a></div>
			
				// <div class="reward" title="Tu as déclenché 50 feux d&#39;artifices, un vrai bout-en-train !"><a href="/medals/Chair à canon/">
					// <div class="reward_picture"><img src="/static/Rewards/generic_chairacanon03.png" alt="Chair à canon" /></div>
					// <div class="reward_name t5">Chair à canon</div>
				// </a></div>
			
				// <div class="reward" title="Ton camp te doit 50 captures de quartier, un vrai conquérant !"><a href="/medals/Conquérant/">
					// <div class="reward_picture"><img src="/static/Rewards/generic_victoire03.png" alt="Conquérant" /></div>
					// <div class="reward_name t5">Conquérant</div>
				// </a></div>
			
				// <div class="reward" title="Ton premier Hôtel de Ville. On y entre comme dans une auberge mais je ne suis pas sûr qu&#39;il y ait des chambres."><a href="/medals/Grand-Maire/">
					// <div class="reward_picture"><img src="/static/Rewards/mairie01.png" alt="Grand-Maire" /></div>
					// <div class="reward_name t5">Grand-Maire</div>
				// </a></div>
			
				// <div class="reward" title="Vous êtes face à un véritable écrivain, avez-vous repéré ses textes parmi les descriptions de quartier ?"><a href="/medals/Gratte-Papier/">
					// <div class="reward_picture"><img src="/static/Rewards/redacteur02.png" alt="Gratte-Papier" /></div>
					// <div class="reward_name t5">Gratte-Papier</div>
				// </a></div>
			
				// <div class="reward" title="Il faut être un peu fou pour traverser les 236 quartiers du jeu ! Pas de doute, Hermès, dieu des voyageurs et de la chance est ton grand pote."><a href="/medals/Hermès/">
					// <div class="reward_picture"><img src="/static/img/ordre.png" alt="Hermès" /></div>
					// <div class="reward_name t5">Hermès</div>
				// </a></div>
			
				// <div class="reward" title="Tu as été le meilleur soldat de la Défense des saisons 1, 3, 4 et 5, ton camp se souviendra de toi à jamais !"><a href="/medals/Héros de la Défense/">
					// <div class="reward_picture"><img src="/static/Rewards/bestplayer_ladefense.png" alt="Héros de la Défense" /></div>
					// <div class="reward_name t5">Héros de la Défense</div>
				// </a></div>
			
				// <div class="reward" title="Ce bon vieux saint Denis a perdu sa tête, aidez-le à la retrouver ! En partant de sa porte jusqu&#39;à sa basilique, en passant par le lieu de sa décollation ça devrait le faire."><a href="/medals/Il a perdu la tête !/">
					// <div class="reward_picture"><img src="/static/img/ordre.png" alt="Il a perdu la tête !" /></div>
					// <div class="reward_name t5">Il a perdu la tête !</div>
				// </a></div>
			
				// <div class="reward" title="Alors comme ça on visite son premier stade en touriste ? C&#39;est un début, mais il va falloir plus d&#39;effort."><a href="/medals/Il va y avoir du sport !/">
					// <div class="reward_picture"><img src="/static/Rewards/sport01.png" alt="Il va y avoir du sport !" /></div>
					// <div class="reward_name t5">Il va y avoir du sport !</div>
				// </a></div>
			
				// <div class="reward" title="Tu as dominé le classement sur tout un mois. Un gagnant, un vrai !"><a href="/medals/Joueur du Mois/">
					// <div class="reward_picture"><img src="/static/Rewards/first_month.png" alt="Joueur du Mois" /></div>
					// <div class="reward_name t5">Joueur du Mois</div>
				// </a></div>
			
				// <div class="reward" title="Obtenue en réalisant 100 charges. Ah ce niveau-là ce n&#39;est pas du courage, c&#39;est du suicide !"><a href="/medals/Kamikaze/">
					// <div class="reward_picture"><img src="/static/Rewards/generic_kamikaze03.png" alt="Kamikaze" /></div>
					// <div class="reward_name t5">Kamikaze</div>
				// </a></div>
			
				// <div class="reward" title="Suivez les traces du petit Napoléon entre la Concorde et la Bastille, en passant par Louxor et le Louvre."><a href="/medals/La Campagne d&#39;Egypte/">
					// <div class="reward_picture"><img src="/static/Rewards/mission_egypte.png" alt="La Campagne d&#39;Egypte" /></div>
					// <div class="reward_name t5">La Campagne d&#39;Egypte</div>
				// </a></div>
			
				// <div class="reward" title="BattleParis a fêté son lancement au bar éphémère des bières Demory et du collectif From Paris, et vous y étiez !"><a href="/medals/Lancement (événement)/">
					// <div class="reward_picture"><img src="/static/Rewards/mission_demory.png" alt="Lancement (événement)" /></div>
					// <div class="reward_name t5">Lancement (événement)</div>
				// </a></div>
			
				// <div class="reward" title="Faites le marché au pied du Sacré-Cœur, léchez les vitrines des Grands Magasins du quartier Printemps, faites glisser les patins à l&#39;Hotel de Ville, et moulinez le tout avec la Grande Roue."><a href="/medals/Le Noël de Paris (événement)/">
					// <div class="reward_picture"><img src="/static/Rewards/noel2012.png" alt="Le Noël de Paris (événement)" /></div>
					// <div class="reward_name t5">Le Noël de Paris (événement)</div>
				// </a></div>
			
				// <div class="reward" title="Partez à la découverte du Paris Noir en visitant les hauts lieux des cultures noires ! Soit la Place Joséphine Baker, Présence Africaine, le marché Dejean, la passerelle Senghor et le Panthéon."><a href="/medals/Le Paris Noir/">
					// <div class="reward_picture"><img src="/static/Rewards/mission_bpw.png" alt="Le Paris Noir" /></div>
					// <div class="reward_name t5">Le Paris Noir</div>
				// </a></div>
			
				// <div class="reward" title="Obtenue en checkant la station “Porte des Lilas”. J&#39;suis le poinçonneur des lilaaaaas, Pour Invalides changer à l&#39;Opéraaaaa (Serge Gainsbourg)"><a href="/medals/Le Poinçonneur des Lilas/">
					// <div class="reward_picture"><img src="/static/Rewards/mission_lilas.png" alt="Le Poinçonneur des Lilas" /></div>
					// <div class="reward_name t5">Le Poinçonneur des Lilas</div>
				// </a></div>
			
				// <div class="reward" title="Une simple tombe pour 500 000 soldat, soit le plus grand cimetière en haut de la plus belle avenue."><a href="/medals/Le Soldat Inconnu/">
					// <div class="reward_picture"><img src="/static/Rewards/soldat_inconnu.png" alt="Le Soldat Inconnu" /></div>
					// <div class="reward_name t5">Le Soldat Inconnu</div>
				// </a></div>
			
				// <div class="reward" title="La ligne dessert le Parc des Princes, le champ de Mars, le carrefour de la Croix-Rouge, la porte de Martin, l’ancien arsenal de François 1er, terminus devant l’hôpital d’Amérique. "><a href="/medals/Le Train Fantôme/">
					// <div class="reward_picture"><img src="/static/Rewards/mission_stationfantome.png" alt="Le Train Fantôme" /></div>
					// <div class="reward_name t5">Le Train Fantôme</div>
				// </a></div>
			
				// <div class="reward" title="La Blanche n&#39;est pas si pure, La Fayette sent le soufre et le Lion de Belfort garde les Enfers."><a href="/medals/Les Enfers à Paris/">
					// <div class="reward_picture"><img src="/static/Rewards/lenfer.png" alt="Les Enfers à Paris" /></div>
					// <div class="reward_name t5">Les Enfers à Paris</div>
				// </a></div>
			
				// <div class="reward" title="Bravo, tu as trouvé ton premier repère d&#39;Indie loser ! Ça se passe comment ce dépucelage ?"><a href="/medals/Les Indie Loses/">
					// <div class="reward_picture"><img src="/static/Rewards/indielose01.png" alt="Les Indie Loses" /></div>
					// <div class="reward_name t5">Les Indie Loses</div>
				// </a></div>
			
				// <div class="reward" title="Obtenue après des checkins dans 6 stations des différentes portes de Paris. Les louuuups, les loups sont entrééés dans Pariiiiis. (Serge Reggiani)"><a href="/medals/Les Loups sont Entrés dans Paris/">
					// <div class="reward_picture"><img src="/static/Rewards/mission_loups.png" alt="Les Loups sont Entrés dans Paris" /></div>
					// <div class="reward_name t5">Les Loups sont Entrés dans Paris</div>
				// </a></div>
			
				// <div class="reward" title="Les morts se lèvent aux Halles, à l&#39;Enfer, au Manoir et au Père Lefauteuil."><a href="/medals/Les Morts-Vibrants/">
					// <div class="reward_picture"><img src="/static/Rewards/mission_zombies.png" alt="Les Morts-Vibrants" /></div>
					// <div class="reward_name t5">Les Morts-Vibrants</div>
				// </a></div>
			
				// <div class="reward" title="Aucune fôte n&#39;aura échappé à Rodolphe (à part celle-ci), le Lucky Luke de l&#39;orthographe !"><a href="/medals/Maître Capello/">
					// <div class="reward_picture"><img src="/static/Rewards/perso_capello.png" alt="Maître Capello" /></div>
					// <div class="reward_name t5">Maître Capello</div>
				// </a></div>
			
				// <div class="reward" title="Être passé dans tous les quartiers de Paris intra-Muros… Il faut avoir des ailes pour ça, Mercure est avec toi !"><a href="/medals/Mercure/">
					// <div class="reward_picture"><img src="/static/img/ordre.png" alt="Mercure" /></div>
					// <div class="reward_name t5">Mercure</div>
				// </a></div>
			
				// <div class="reward" title="Par saints Ambroise, Augustin, Cloud, Denis, Émilion, Fargeau, François-Xavier, Georges, Germain, Gervais, Jacques, Lambert, Lazare, Mandé, Martin, Maur, Marcel, Michel, Ouen, Paul, Philippe, Placide, Sébastien, Sulpice, Victor, tu les as tous faits ! Tu n’as pas oublié Anne au moins ?"><a href="/medals/Par tous les Saints !/">
					// <div class="reward_picture"><img src="/static/img/ordre.png" alt="Par tous les Saints !" /></div>
					// <div class="reward_name t5">Par tous les Saints !</div>
				// </a></div>
			
				// <div class="reward" title="WIHOOOOOOOOON WIHOOOOOOOOON WIHOOOOOOOOON WIHOOOOOOOOON. Tu viens de sauver un quartier de ton camp, c&#39;était moins une !"><a href="/medals/Pompier/">
					// <div class="reward_picture"><img src="/static/Rewards/fireman01.png" alt="Pompier" /></div>
					// <div class="reward_name t5">Pompier</div>
				// </a></div>
			
				// <div class="reward" title="Ce beta-testeur a rendu des services inestimables à la communauté BattleParis, respect."><a href="/medals/Preums!/">
					// <div class="reward_picture"><img src="/static/Rewards/preums_star.png" alt="Preums!" /></div>
					// <div class="reward_name t5">Preums!</div>
				// </a></div>
			
				// <div class="reward" title="Après avoir visité 100 quartiers différents, tu dois avoir un paquet d&#39;histoires à raconter."><a href="/medals/Scout/">
					// <div class="reward_picture"><img src="/static/Rewards/generic_explorateur03.png" alt="Scout" /></div>
					// <div class="reward_name t5">Scout</div>
				// </a></div>
			
				// <div class="reward" title="À trop avoir la tête en l&#39;air on finit nez-à-nez avec de drôles de choses... Merci de nous avoir aidés à dénicher des aliens en mosaïque !"><a href="/medals/Space Explorer/">
					// <div class="reward_picture"><img src="/static/Rewards/spacexplorer.png" alt="Space Explorer" /></div>
					// <div class="reward_name t5">Space Explorer</div>
				// </a></div>
			
				// <div class="reward" title="Alors-là chapeau, 150 Space Invaders différents découverts, difficile de faire mieux !"><a href="/medals/Space Oddity/">
					// <div class="reward_picture"><img src="/static/Rewards/spaceinvader07.png" alt="Space Oddity" /></div>
					// <div class="reward_name t5">Space Oddity</div>
				// </a></div>
			
				// <div class="reward" title="10 lieux touristiques, un vrai paparazzi ! N&#39;oublie quand même pas la banane, les sandales et le short."><a href="/medals/Super Touriste/">
					// <div class="reward_picture"><img src="/static/Rewards/supertourist02.png" alt="Super Touriste" /></div>
					// <div class="reward_name t5">Super Touriste</div>
				// </a></div>
			
				// <div class="reward" title="Tu as visité l&#39;Ile de la Cité, berceau de Paris et accessoirement Quartier Général de la Team Lutèce."><a href="/medals/Visiteur de L&#39;Origine/">
					// <div class="reward_picture"><img src="/static/Rewards/scout_origine.png" alt="Visiteur de L&#39;Origine" /></div>
					// <div class="reward_name t5">Visiteur de L&#39;Origine</div>
				// </a></div>
			
				// <div class="reward" title="Tu as visité les trois Quartiers Généraux des bords de Seine : le Champ de Mars, l&#39;Île de la Cité et Bercy."><a href="/medals/Visiteur de Seine/">
					// <div class="reward_picture"><img src="/static/Rewards/scout_vaux.png" alt="Visiteur de Seine" /></div>
					// <div class="reward_name t5">Visiteur de Seine</div>
				// </a></div>
			
				// <div class="reward" title="Aller jusqu&#39;aux quatre Quartiers Généraux de banlieue, Saint-Denis Ville, Vincennes Ville, Cachan et le Parvis de la Défense... il faut le vouloir !"><a href="/medals/Visiteur des Alentours/">
					// <div class="reward_picture"><img src="/static/img/ordre.png" alt="Visiteur des Alentours" /></div>
					// <div class="reward_name t5">Visiteur des Alentours</div>
				// </a></div>
			
				// <div class="reward" title="Tu as gravi les trois monts Quartiers Généraux de Paris : Montmartre, Belleville et Montparnasse. Courageux !"><a href="/medals/Visiteur des Monts/">
					// <div class="reward_picture"><img src="/static/Rewards/scout_monts.png" alt="Visiteur des Monts" /></div>
					// <div class="reward_name t5">Visiteur des Monts</div>
				// </a></div>
			
				// <div class="reward" title="Tu as visité tous les Quartiers Généraux de Paris, intra-muros, il faut du cran pour ça !"><a href="/medals/Visiteur entre les Murs/">
					// <div class="reward_picture"><img src="/static/Rewards/scout_total.png" alt="Visiteur entre les Murs" /></div>
					// <div class="reward_name t5">Visiteur entre les Murs</div>
				// </a></div>
			
				// <div class="reward" title="Obtenue après ton premier checkin sur une station de la ligne A du RER, comme c&#39;est mignon."><a href="/medals/Vétéran du RER A/">
					// <div class="reward_picture"><img src="/static/Rewards/transport/lineA_01.png" alt="Vétéran du RER A" /></div>
					// <div class="reward_name t5">Vétéran du RER A</div>
				// </a></div>
			
				// <div class="reward" title="Obtenue après ton premier checkin sur une station de la ligne B du RER, comme c&#39;est mignon."><a href="/medals/Vétéran du RER B/">
					// <div class="reward_picture"><img src="/static/Rewards/transport/lineB_01.png" alt="Vétéran du RER B" /></div>
					// <div class="reward_name t5">Vétéran du RER B</div>
				// </a></div>
			
				// <div class="reward" title="Obtenue après 25 checkins sur au moins 4 stations de la ligne C du RER, on y arrive."><a href="/medals/Vétéran du RER C/">
					// <div class="reward_picture"><img src="/static/Rewards/transport/lineC_02.png" alt="Vétéran du RER C" /></div>
					// <div class="reward_name t5">Vétéran du RER C</div>
				// </a></div>
			
				// <div class="reward" title="Obtenue après ton premier checkin sur une station de la ligne D du RER, comme c&#39;est mignon."><a href="/medals/Vétéran du RER D/">
					// <div class="reward_picture"><img src="/static/Rewards/transport/lineD_01.png" alt="Vétéran du RER D" /></div>
					// <div class="reward_name t5">Vétéran du RER D</div>
				// </a></div>
			
				// <div class="reward" title="Obtenue après ton premier checkin sur une station de la ligne E du RER, comme c&#39;est mignon."><a href="/medals/Vétéran du RER E/">
					// <div class="reward_picture"><img src="/static/Rewards/transport/lineE_01.png" alt="Vétéran du RER E" /></div>
					// <div class="reward_name t5">Vétéran du RER E</div>
				// </a></div>
			
				// <div class="reward" title="Obtenue après ton premier checkin sur une station de la ligne H du Transilien, comme c&#39;est mignon."><a href="/medals/Vétéran du Transilien H/">
					// <div class="reward_picture"><img src="/static/Rewards/transport/lineH_01.png" alt="Vétéran du Transilien H" /></div>
					// <div class="reward_name t5">Vétéran du Transilien H</div>
				// </a></div>
			
				// <div class="reward" title="Obtenue après ton premier checkin sur une station de la ligne J du Transilien, comme c&#39;est mignon."><a href="/medals/Vétéran du Transilien J/">
					// <div class="reward_picture"><img src="/static/Rewards/transport/lineJ_01.png" alt="Vétéran du Transilien J" /></div>
					// <div class="reward_name t5">Vétéran du Transilien J</div>
				// </a></div>
			
				// <div class="reward" title="Obtenue après ton premier checkin sur une station de la ligne K du Transilien, comme c&#39;est mignon."><a href="/medals/Vétéran du Transilien K/">
					// <div class="reward_picture"><img src="/static/Rewards/transport/lineK_01.png" alt="Vétéran du Transilien K" /></div>
					// <div class="reward_name t5">Vétéran du Transilien K</div>
				// </a></div>
			
				// <div class="reward" title="Obtenue après ton premier checkin sur une station de la ligne L du Transilien, comme c&#39;est mignon."><a href="/medals/Vétéran du Transilien L/">
					// <div class="reward_picture"><img src="/static/Rewards/transport/lineL_01.png" alt="Vétéran du Transilien L" /></div>
					// <div class="reward_name t5">Vétéran du Transilien L</div>
				// </a></div>
			
				// <div class="reward" title="Obtenue après ton premier checkin sur une station de la ligne N du Transilien, comme c&#39;est mignon."><a href="/medals/Vétéran du Transilien N/">
					// <div class="reward_picture"><img src="/static/Rewards/transport/lineN_01.png" alt="Vétéran du Transilien N" /></div>
					// <div class="reward_name t5">Vétéran du Transilien N</div>
				// </a></div>
			
				// <div class="reward" title="Obtenue après ton premier checkin sur une station de la ligne R du Transilien, comme c&#39;est mignon."><a href="/medals/Vétéran du Transilien R/">
					// <div class="reward_picture"><img src="/static/Rewards/transport/lineR_01.png" alt="Vétéran du Transilien R" /></div>
					// <div class="reward_name t5">Vétéran du Transilien R</div>
				// </a></div>
			
				// <div class="reward" title="Obtenue après 10 checkins sur au moins 4 stations de la ligne 1 du métro, on y vient."><a href="/medals/Vétéran du métro 1/">
					// <div class="reward_picture"><img src="/static/Rewards/transport/line01_02.png" alt="Vétéran du métro 1" /></div>
					// <div class="reward_name t5">Vétéran du métro 1</div>
				// </a></div>
			
				// <div class="reward" title="Obtenue après 10 checkins sur au moins 4 stations de la ligne 10 du métro, on y vient."><a href="/medals/Vétéran du métro 10/">
					// <div class="reward_picture"><img src="/static/Rewards/transport/line10_02.png" alt="Vétéran du métro 10" /></div>
					// <div class="reward_name t5">Vétéran du métro 10</div>
				// </a></div>
			
				// <div class="reward" title="Obtenue après ton premier checkin sur une station de la ligne 11 du métro, comme c&#39;est mignon."><a href="/medals/Vétéran du métro 11/">
					// <div class="reward_picture"><img src="/static/Rewards/transport/line11_01.png" alt="Vétéran du métro 11" /></div>
					// <div class="reward_name t5">Vétéran du métro 11</div>
				// </a></div>
			
				// <div class="reward" title="Obtenue après 10 checkins sur au moins 4 stations de la ligne 12 du métro, on y vient."><a href="/medals/Vétéran du métro 12/">
					// <div class="reward_picture"><img src="/static/Rewards/transport/line12_02.png" alt="Vétéran du métro 12" /></div>
					// <div class="reward_name t5">Vétéran du métro 12</div>
				// </a></div>
			
				// <div class="reward" title="Obtenue après 10 checkins sur au moins 4 stations de la ligne 13 du métro, on y vient."><a href="/medals/Vétéran du métro 13/">
					// <div class="reward_picture"><img src="/static/Rewards/transport/line13_02.png" alt="Vétéran du métro 13" /></div>
					// <div class="reward_name t5">Vétéran du métro 13</div>
				// </a></div>
			
				// <div class="reward" title="Obtenue après 10 checkins sur au moins 4 stations de la ligne 14 du métro, on y vient."><a href="/medals/Vétéran du métro 14/">
					// <div class="reward_picture"><img src="/static/Rewards/transport/line14_02.png" alt="Vétéran du métro 14" /></div>
					// <div class="reward_name t5">Vétéran du métro 14</div>
				// </a></div>
			
				// <div class="reward" title="Obtenue après 10 checkins sur au moins 4 stations de la ligne 2 du métro, on y vient."><a href="/medals/Vétéran du métro 2/">
					// <div class="reward_picture"><img src="/static/Rewards/transport/line02_02.png" alt="Vétéran du métro 2" /></div>
					// <div class="reward_name t5">Vétéran du métro 2</div>
				// </a></div>
			
				// <div class="reward" title="Obtenue après 10 checkins sur au moins 4 stations de la ligne 3 du métro, on y vient."><a href="/medals/Vétéran du métro 3/">
					// <div class="reward_picture"><img src="/static/Rewards/transport/line03_02.png" alt="Vétéran du métro 3" /></div>
					// <div class="reward_name t5">Vétéran du métro 3</div>
				// </a></div>
			
				// <div class="reward" title="Obtenue après 10 checkins sur au moins 4 stations de la ligne 4 du métro, on y vient."><a href="/medals/Vétéran du métro 4/">
					// <div class="reward_picture"><img src="/static/Rewards/transport/line04_02.png" alt="Vétéran du métro 4" /></div>
					// <div class="reward_name t5">Vétéran du métro 4</div>
				// </a></div>
			
				// <div class="reward" title="Obtenue après ton premier checkin sur une station de la ligne 5 du métro, comme c&#39;est mignon."><a href="/medals/Vétéran du métro 5/">
					// <div class="reward_picture"><img src="/static/Rewards/transport/line05_01.png" alt="Vétéran du métro 5" /></div>
					// <div class="reward_name t5">Vétéran du métro 5</div>
				// </a></div>
			
				// <div class="reward" title="Obtenue après 10 checkins sur au moins 4 stations de la ligne 6 du métro, on y vient."><a href="/medals/Vétéran du métro 6/">
					// <div class="reward_picture"><img src="/static/Rewards/transport/line06_02.png" alt="Vétéran du métro 6" /></div>
					// <div class="reward_name t5">Vétéran du métro 6</div>
				// </a></div>
			
				// <div class="reward" title="Obtenue après 10 checkins sur au moins 4 stations de la ligne 7 du métro, on y vient."><a href="/medals/Vétéran du métro 7/">
					// <div class="reward_picture"><img src="/static/Rewards/transport/line07_02.png" alt="Vétéran du métro 7" /></div>
					// <div class="reward_name t5">Vétéran du métro 7</div>
				// </a></div>
			
				// <div class="reward" title="Obtenue après ton premier checkin sur une station de la ligne 7bis du métro, comme c&#39;est mignon."><a href="/medals/Vétéran du métro 7bis/">
					// <div class="reward_picture"><img src="/static/Rewards/transport/line07bis_01.png" alt="Vétéran du métro 7bis" /></div>
					// <div class="reward_name t5">Vétéran du métro 7bis</div>
				// </a></div>
			
				// <div class="reward" title="Obtenue après 10 checkins sur au moins 4 stations de la ligne 8 du métro, on y vient."><a href="/medals/Vétéran du métro 8/">
					// <div class="reward_picture"><img src="/static/Rewards/transport/line08_02.png" alt="Vétéran du métro 8" /></div>
					// <div class="reward_name t5">Vétéran du métro 8</div>
				// </a></div>
			
				// <div class="reward" title="Obtenue après 10 checkins sur au moins 4 stations de la ligne 9 du métro, on y vient."><a href="/medals/Vétéran du métro 9/">
					// <div class="reward_picture"><img src="/static/Rewards/transport/line09_02.png" alt="Vétéran du métro 9" /></div>
					// <div class="reward_name t5">Vétéran du métro 9</div>
				// </a></div>
			
				// <div class="reward" title="Obtenue après ton premier checkin sur une station de la ligne T1 du tramway, comme c&#39;est mignon."><a href="/medals/Vétéran du tram T1/">
					// <div class="reward_picture"><img src="/static/Rewards/transport/lineT1_01.png" alt="Vétéran du tram T1" /></div>
					// <div class="reward_name t5">Vétéran du tram T1</div>
				// </a></div>
			
				// <div class="reward" title="Obtenue après ton premier checkin sur une station de la ligne T2 du tramway, comme c&#39;est mignon."><a href="/medals/Vétéran du tram T2/">
					// <div class="reward_picture"><img src="/static/Rewards/transport/lineT2_01.png" alt="Vétéran du tram T2" /></div>
					// <div class="reward_name t5">Vétéran du tram T2</div>
				// </a></div>
			
				// <div class="reward" title="Obtenue après ton premier checkin sur une station de la ligne T3a du tramway, comme c&#39;est mignon."><a href="/medals/Vétéran du tram T3a/">
					// <div class="reward_picture"><img src="/static/Rewards/transport/lineT3a_01.png" alt="Vétéran du tram T3a" /></div>
					// <div class="reward_name t5">Vétéran du tram T3a</div>
				// </a></div>
			
				// <div class="reward" title="Obtenue après ton premier checkin sur une station de la ligne de tramway T3b, comme c&#39;est mignon."><a href="/medals/Vétéran du tram T3b/">
					// <div class="reward_picture"><img src="/static/Rewards/transport/lineT3b_01.png" alt="Vétéran du tram T3b" /></div>
					// <div class="reward_name t5">Vétéran du tram T3b</div>
				// </a></div>