var msg = {
	logged: $('#login').length == 0,
	name: '',
	picto: null,
	total: 0,
	checked: 0,
	left: 0
};

if (msg.logged) {
	// User logged in
	$('.place_counter').each(function() {
		var c = parseInt($(this).text(), 10);
		msg.total += c;
		if (c == 0) {
			$(this).closest('li').css('background-color', 'red').css('color', 'white');
			$(this).css('background-color', 'red').css('background-image', 'none');
			msg.left++;
		}
		else {
			msg.checked++;
		}
	});

	msg.name = $('.menupad > .t6').first().text();
	
	msg.picto = 'http://battle.paris' + $('.medal_big > img').attr('src');
}

chrome.runtime.sendMessage(msg);
